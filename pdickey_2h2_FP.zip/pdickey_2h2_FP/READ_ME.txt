Phillip Dickey & Musa Hassan
Professor Megistu
CS 211H: Object-Oriented-Programming
10 May 2022

This directory contains all relevant aspects of the Final Project by Phillip Dickey and Musa Hassan.

The jsoup.jar is provided due to it being necessary to the final program.

What is:

	src.zip --> Zip folder containing the two packages of the program.
	  	-
	  	-
	  	-->Contains gui_images and scraperPackage packages
	  	-
	  	-
	  	-->gui_images
	  	-  -
	  	-  -
	  	-  --> package that contains the images that are used by certain graphical elements in the GUI
	  	-
	  	-
	  	-->scraperPackager
	     	-
	     	-
	     	--> package that contains classes used to scrape the various websites and the classes used for graphical output

	doc.zip --> zip folder containing this program's "official" javadoc documentation
	  	-
	  	-
	  	-->Full documentation can be accessed starting at the "index.html" file
	  	-
	  	-
	  	-->Provides a crystal clear method of viewing the various aspects of the program and their documentation

	<name>id.txt --> two id.txt files have been provided to identify the members of the group